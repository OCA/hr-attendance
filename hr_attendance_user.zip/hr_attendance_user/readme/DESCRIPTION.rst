The module allows a user with a role of Manual Attendance to see their own
attendance records, and only their own.
