Just install the module and the user with role Manual Attendance could only see
their attendances.
